
Assembly Drawing (A3) - Designators.pdf

	Contains A3 top assembly drawing with anotated designators.


Assembly Drawing (A3) - Comments.pdf

	Contains A3 top assembly drawing with anotated component values.


GE6P R2A Assembly Notes.doc

	Contains 3 notes on placement/assembly.


Pick & Place CAM Outputs

	Pick Place for GE6P R2A.xls
	Pick Place for GE6P R2A.txt
	Pick Place for GE6P R2A.csv

BOM CAM Outputs

	BOM for GE6P R2A.xls
	BOM for GE6P R2A.txt
	BOM for GE6P R2A.csv
